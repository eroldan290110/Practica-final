import './style/app.scss'
import Login from './components/login';
import Home from './components/Home';
import { BrowserRouter, Routes, Route } from 'react-router-dom'


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route exact path="/" element={<Login />} />
        <Route path="/home" element={<Home/>} />
        <Route path="*" element={<div><h1>Página no encontrada</h1></div>} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;