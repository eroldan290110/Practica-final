import { useState } from 'react';
import { CssBaseline, Box, Button, Container, Stack, TextField } from '@mui/material';
import Swal from 'sweetalert2';
import { useNavigate } from "react-router-dom";

function Login() {
    const [user, setUser] = useState('');
    const [password, setPassword] = useState('');
    let History = useNavigate();

    const Toast = Swal.mixin({
        toast: true,
        position: 'center',
        showConfirmButton: false,
        timer: 3000
    })

    function SignIn() {
        var message = {
            title: "",
            icon: ""
        };

        fetch(`http://localhost:7257/api/User/${user}/${password}`)
            .then(response => response.json())
            .then(data => {
                if (data)
                    History("/home")
                else {
                    message = {
                        title: "Usuario y/o contraseña inválida",
                        icon: "error"
                    };

                    Toast.fire({
                        target: document.getElementById("app"),
                        ...message
                    })
                }
            });
    }

    return (
        <div className='login'>
            <CssBaseline />
            <Container className="login-content d-flex justify-content-center" maxWidth="sm">
                <Box className="w-100">
                    <h3>Iniciar sesión</h3>
                    <form className=" border border-3 border-light"
                        onSubmit={e => {
                            e.preventDefault();
                            SignIn();
                        }}>
                        <Stack spacing={3}>
                            <TextField
                                className="w-100"
                                label="Usuario"
                                type="text"
                                variant="standard"
                                color="success"
                                value={user}
                                onChange={e => setUser(e.target.value)}
                                required
                            />
                            <TextField
                                className="w-100"
                                label="Contaseña"
                                type="password"
                                variant="standard"
                                color="success"
                                value={password}
                                onChange={e => setPassword(e.target.value)}
                                required
                            />
                            <Button type='submit'
                                className="w-100"
                                variant="contained"
                                color="primary">Ingresar
                            </Button>
                        </Stack>
                    </form>
                </Box>
            </Container>
        </div>
    )
}
export default Login;