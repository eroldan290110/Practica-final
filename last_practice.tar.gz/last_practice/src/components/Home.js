import * as React from 'react';
import Post from "./Post";
import NavBar from './NavBar';

import { Stack } from "@mui/material";

const Home = () => {
    const [users, setUsers] = React.useState([])

    React.useEffect(() => {
        fetch(`http://localhost:7257/api/Post`)
            .then(response => response.json())
            .then(data => {
                if (data.length > 0)
                    setUsers(data)
            });
    }, [])

    return (
        <div>
            <NavBar />
            <Stack className='w-100' direction="row" spacing={4}>
                {users.map((user) => {
                    return <Post user={user} />
                })}
            </Stack>
        </div>
    );
}
export default Home;